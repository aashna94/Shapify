//
//  GameScene.swift
//  Choose Figure
//
//  Created by Ivan Sosnovik on 07.02.16.
//  Copyright (c) 2016 ivansosnovik. All rights reserved.
//

import SpriteKit


public class GameScene: SKScene {
    
    var level: Int = 1
    var timer:Int = 0
    //var tryAgain: String = "Try Again"
    var logic: GameActions?
    
    var levelLabelNode: SKLabelNode?
    var timerLabelNode: SKLabelNode?
    //var tryAgainLabelNode: SKLabelNode?
    var rightFigureNode: SKSpriteNode?
    var deckNodes: [SKSpriteNode] = []
    var deckNodesName: [String] = []
    var lifeNodes: [SKSpriteNode] = []
    var lives: Int = 3
    
    
    // preparations
    public override func didMove(to view: SKView) {
        let action = SKAction.playSoundFileNamed("nextLevel.mp3", waitForCompletion: false)
        self.run(action)

        
        // connect nodes with scene
        self.levelLabelNode = childNode(withName: "level") as? SKLabelNode
        self.timerLabelNode = childNode(withName: "timer") as? SKLabelNode
        //self.tryAgainLabelNode = childNode(withName: "tryAgain") as? SKLabelNode
        self.rightFigureNode = childNode(withName: "rightFigure") as? SKSpriteNode
        
        enumerateChildNodes(withName: "//*") {
            node, stop in
            if node.name == "figure" {
                self.deckNodes.append(node as! SKSpriteNode)
                self.deckNodesName.append("")
            }
            if node.name == "life" {
                self.lifeNodes.append(node as! SKSpriteNode)
            }
        }
        // configure the label
        self.levelLabelNode?.text = String(level)
        self.timerLabelNode?.text = String(timer)
        //self.tryAgainLabelNode?.text = String(tryAgain)
        // configure logic
        self.logic = GameLogic()
        logic?.setupLogic(delegate: self, deckSize: deckNodes.count)
        // Draw sprites
        drawDeck()
        drawRightFigure()
        drawLives()
        setupTimer()
    }
    
}


// MARK: - Drawings
extension GameScene {
    
    func drawDeck() {
        for (index, node) in deckNodes.enumerated() {
            let name = logic?.deck[index]
            self.deckNodesName[index] = name!
            node.texture = SKTexture(imageNamed: name!)
            node.xScale = 1.5
            node.yScale = 1.5
        }
    }
    
    func drawRightFigure() {
        let name = logic?.rightFigureName
        self.rightFigureNode?.texture = SKTexture(imageNamed: name!)
    }
    
    func drawLives() {
        if lives < 3 {
            for index in lives...2 {
                let node = lifeNodes[index]
                node.alpha = 0.2
            }
        }
    }
    
    func setupTimer() {
        var timer = 0
        if (level >= 1 && level <=  15) {
            timer = 7
        } else if (level >= 16 && level <=  35) {
            timer = 10
        } else if (level >= 36 && level <=  45) {
            timer = 15
        } else if (level >= 46 && level <=  65) {
            timer = 17
        } else if (level >= 66 && level <=  85) {
            timer = 20
        } else if (level >= 86 && level <=  105) {
            timer = 23
        } else if (level >= 106 && level <=  120) {
            timer = 25
        }
        
        let runTimer = timer
        let waitTimer = SKAction.wait(forDuration: 1)
        let actionTimer = SKAction.run {
            self.timerLabelNode?.text = "Timer : \(timer)"
            if timer == 1 {
                //self.tryAgainLabelNode?.isHidden = false
                let action = SKAction.playSoundFileNamed("lose.mp3", waitForCompletion: false)
                self.run(action)
                let namaste = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
                namaste.text = "Time Up..Try Again 😭"
                //        namaste.zPosition = 0
                namaste.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: namaste.frame.width * 1.25 , height: namaste.frame.height * 2.5))
                namaste.physicsBody?.isDynamic = false
                namaste.fontSize = 50
                namaste.fontColor = SKColor.black
                namaste.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
                self.addChild(namaste)
                namaste.alpha = 1
                namaste.zPosition = 4
                var fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
                fadeOutAction.timingMode = .easeInEaseOut
                namaste.run(fadeOutAction, completion: {
                    namaste.alpha = 1
                })
                
                
                let button = ResetButton()
                //button.name = buttonNodeName
                button.position = CGPoint(x: self.frame.midX, y: self.frame.midY - (namaste.frame.height + 10))
                button.delegate = self
                button.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: button.frame.width * 1.25 , height: button.frame.height * 2.5))
                button.physicsBody?.isDynamic = false
                self.addChild(button)
                button.alpha = 1
                fadeOutAction = SKAction.fadeIn(withDuration: 1.5) //SKAction.fadeOut(withDuration: 1.25)
                fadeOutAction.timingMode = .easeInEaseOut
                button.run(fadeOutAction, completion: {
                    button.alpha = 1
                })
                
                print("Game Over!!!")
            }
            else {
                timer = timer - 1
            }
        }
        
        
        run(SKAction.repeat(SKAction.sequence([waitTimer, actionTimer]) , count: runTimer ))
    }
    
}

// MARK: - Event Delegation
extension GameScene: GameEvents {
    
    func userDidRightChoice(index: Int) {
        _ = deckNodes[index]
        let action = SKAction.playSoundFileNamed("rightFig.mp3", waitForCompletion: false)
        self.run(action)
        let name = deckNodes[index]
        let textureName = deckNodesName[index]
        name.texture = SKTexture(imageNamed: "\(textureName)S.png")
        name.xScale = 1.0
        name.yScale = 1.0
        print("Cool!!!!")
    }
    
    func userDidWrongChoice() {
        var action = SKAction.playSoundFileNamed("wrongFig.mp3", waitForCompletion: false)
        self.run(action)
        let index = lives - 1
        let lifeNode = lifeNodes[index]
        action = SKAction.fadeAlpha(to: 0.2, duration: 0.1)
        lifeNode.run(action)
        drawLives()
        print("Fail!!! Lives: \(lives)")
    }
    
}


extension GameScene {
    
    func gameOver() {
        
        let action = SKAction.playSoundFileNamed("lose.mp3", waitForCompletion: true)
        self.run(action)
        let namaste = SKLabelNode(fontNamed: "HelveticaNeue-Bold")
        namaste.text = "You Lose 😭"
        //        namaste.zPosition = 0
        namaste.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: namaste.frame.width * 1.25 , height: namaste.frame.height * 2.5))
        namaste.physicsBody?.isDynamic = false
        namaste.fontSize = 50
        namaste.fontColor = SKColor.black
        namaste.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(namaste)
        namaste.alpha = 1
        namaste.zPosition = 4
        var fadeOutAction = SKAction.fadeIn(withDuration: 1) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        namaste.run(fadeOutAction, completion: {
            namaste.alpha = 1
        })
        
        
        let button = ResetButton()
        //button.name = buttonNodeName
        button.position = CGPoint(x: frame.midX, y: frame.midY - (namaste.frame.height + 10))
        button.delegate = self
        button.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: button.frame.width * 1.25 , height: button.frame.height * 2.5))
        button.physicsBody?.isDynamic = false
        addChild(button)
        button.alpha = 1
        fadeOutAction = SKAction.fadeIn(withDuration: 1.5) //SKAction.fadeOut(withDuration: 1.25)
        fadeOutAction.timingMode = .easeInEaseOut
        button.run(fadeOutAction, completion: {
            button.alpha = 1
        })
        
        print("Game Over!!!")
    }
    
    
    func moveToNextLevel() {
        let action = SKAction.playSoundFileNamed("nextLevel.mp3", waitForCompletion: false)
        self.run(action)
        let transition = SKTransition.crossFade(withDuration: 0)
        let nextLevelScene = GameScene(fileNamed:"GameScene")
        nextLevelScene!.level = level + 1
        nextLevelScene!.lives = lives
        nextLevelScene!.scaleMode = SKSceneScaleMode.aspectFill
        self.scene!.view?.presentScene(nextLevelScene!, transition: transition)
    }
}

// MARK: - Touches
extension GameScene {
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let position = touch.location(in: self)
            let node = self.atPoint(position)
            if node.name == "figure" {
                let figure = node as? SKSpriteNode
                let index = deckNodes.index(of: figure!)
                self.logic?.userChoose(index: index!)
                //                figure!.run(SKAction.sequence([SKAction.moveBy(x: 0.0,y: 200.0,duration: 0.2),
                //                                            SKAction.moveBy(x: 0.0,y: -20.0,duration: 0.2)]))
                //                figure!.texture = SKTexture(imageNamed: "12.png")
            }
        }
    }
}

extension GameScene: ResetButtonDelegate {
    
    func didTapReset(sender: ResetButton) {
        let action = SKAction.playSoundFileNamed("popSound.mp3", waitForCompletion: false)
        self.run(action)
        let transition = SKTransition.crossFade(withDuration: 0)
        
        let scene1 = GameScene(fileNamed:"GameScene")
        scene1!.level = level
        //scene1!.lives = Lives
        scene1!.scaleMode = SKSceneScaleMode.aspectFill
        self.scene!.view?.presentScene(scene1!, transition: transition)
    }
}

